<?php
 return array (
  'theme_color' => 'default',
  'background_url' => 'https://hoanghamobile.com/tin-tuc/wp-content/uploads/2023/09/hinh-nen-may-tinh-4k-cong-nghe-9.jpg',
  'theme_sidebar' => 'dark',
  'theme_header' => 'dark',
  'custom_html' => '',
) ;