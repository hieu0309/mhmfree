<!DOCTYPE html>
<html>

<head>
        <head>
    <meta charset="utf-8">
<meta name="description" content="Hệ Thống Cung Cấp 4G VPN Hàng Đầu Việt Nam - Data Vô Hạn Dung Lượng - Tốc Độ Cao - Giá Rẻ - Hỗ Trợ Chuyển Vùng - Tăng Tốc Gaming - Giảm Lag Ping ">
<meta name="keywords" content=" genz vpn, 4g giá rẻ, 5g giá rẻ, 4g vpn, hack 4g, shadowrocket, 3g, 4g, 5g, 4g vpn, vpn 4g, vpn 5g, 5g vpn, 5g tốc độ, 5g giá rẻ, vpn tốc độ, 5g data, tenvpndata 5g, 4g tốc độ, vpn siêu cấp, data giá rẻ">
<meta property="og:url" content="">
<meta property="og:type" content="website">
<meta property="og:title" content="4G VPN TỐC ĐỘ CAO GIÁ RẺ">
<meta property="og:description" content="Hệ Thống Cung Cấp 4G VPN Hàng Đầu Việt Nam - Data Vô Hạn Dung Lượng - Tốc Độ Cao - Giá Rẻ - Hỗ Trợ Chuyển Vùng - Tăng Tốc Gaming - Giảm Lag Ping ">
<meta property="og:image" content="https://cdn.tgdd.vn/Files/2016/10/16/900599/4g.jpg">
<meta property="og:image:alt" content="https://cdn.tgdd.vn/Files/2016/10/16/900599/4g.jpg">
<link rel="icon" href="https://fiverr-res.cloudinary.com/image/upload/f_png,q_auto,t_makers_project_variation_preview/v1/secured-attachments/makers_project_variation/preview_file/f9bc99ac01f77e8b2b619a88af94cabf-1698962469/653d7078da1beb23b920a33a.svg?__cld_token__=exp=1710629568~hmac=dff7b8817d737d838f203d72b5b50522db7198d6e8f45abba246e5987e398f03">
    <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/components.chunk.css?v=<?php echo e($version); ?>">
    <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/umi.css?v=<?php echo e($version); ?>">
    <?php if(file_exists(public_path("/theme/{$theme}/assets/custom.css"))): ?>
        <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/custom.css?v=<?php echo e($version); ?>">
    <?php endif; ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <?php ($colors = [
        'darkblue' => '#3b5998',
        'black' => '#343a40',
        'default' => '#0665d0',
        'green' => '#319795'
    ]); ?>
    <meta name="theme-color" content="<?php echo e($colors[$theme_config['theme_color']]); ?>">

    <title><?php echo e($title); ?></title>
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,400i,600,700"> -->
    <script>window.routerBase = "/";</script>
    <script>
        window.settings = {
            title: '<?php echo e($title); ?>',
            assets_path: '/theme/<?php echo e($theme); ?>/assets',
            theme: {
                sidebar: '<?php echo e($theme_config['theme_sidebar']); ?>',
                header: '<?php echo e($theme_config['theme_header']); ?>',
                color: '<?php echo e($theme_config['theme_color']); ?>',
            },
            version: '<?php echo e($version); ?>',
            background_url: '<?php echo e($theme_config['background_url']); ?>',
            description: '<?php echo e($description); ?>',
            i18n: [
                'zh-CN',
                'en-US',
                'ja-JP',
                'vi-VN',
                'ko-KR',
                'zh-TW',
                'fa-IR'
            ],
            logo: '<?php echo e($logo); ?>'
        }
    </script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/zh-CN.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/zh-TW.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/en-US.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/ja-JP.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/vi-VN.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/ko-KR.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/fa-IR.js?v=<?php echo e($version); ?>"></script>
</head>

<body>
<div id="root"></div>
<?php echo $theme_config['custom_html']; ?>

<script src="/theme/<?php echo e($theme); ?>/assets/vendors.async.js?v=<?php echo e($version); ?>"></script>
<script src="/theme/<?php echo e($theme); ?>/assets/components.async.js?v=<?php echo e($version); ?>"></script>
<script src="/theme/<?php echo e($theme); ?>/assets/umi.js?v=<?php echo e($version); ?>"></script>
<?php if(file_exists(public_path("/theme/{$theme}/assets/custom.js"))): ?>
    <script src="/theme/<?php echo e($theme); ?>/assets/custom.js?v=<?php echo e($version); ?>"></script>
<?php endif; ?>
</body>

</html>
<html>

<div class="snowflakes" aria-hidden="true">
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
  <div class="snowflake">❅</div>
  <div class="snowflake">❆</div>
</div>

<style>
  @-webkit-keyframes snowflakes-fall {
    0% {top:-10%}
    100% {top:100%}
  }
  @-webkit-keyframes snowflakes-shake {
    0%,100% {-webkit-transform:translateX(0);transform:translateX(0)}
    50% {-webkit-transform:translateX(80px);transform:translateX(80px)}
  }
  @keyframes    snowflakes-fall {
    0% {top:-10%}
    100% {top:100%}
  }
  @keyframes    snowflakes-shake {
    0%,100%{ transform:translateX(0)}
    50% {transform:translateX(80px)}
  }
  .snowflake {
    color: #fff;
    font-size: 1em;
    font-family: Arial, sans-serif;
    text-shadow: 0 0 5px #000;
    position:fixed;
    top:-10%;
    z-index:9999;
    -webkit-user-select:none;
    -moz-user-select:none;
    -ms-user-select:none;
    user-select:none;
    cursor:default;
    -webkit-animation-name:snowflakes-fall,snowflakes-shake;
    -webkit-animation-duration:10s,3s;
    -webkit-animation-timing-function:linear,ease-in-out;
    -webkit-animation-iteration-count:infinite,infinite;
    -webkit-animation-play-state:running,running;
    animation-name:snowflakes-fall,snowflakes-shake;
    animation-duration:10s,3s;
    animation-timing-function:linear,ease-in-out;
    animation-iteration-count:infinite,infinite;
    animation-play-state:running,running;
  }
  .snowflake:nth-of-type(0){
    left:1%;-webkit-animation-delay:0s,0s;animation-delay:0s,0s
  }
  .snowflake:nth-of-type(1){
    left:10%;-webkit-animation-delay:1s,1s;animation-delay:1s,1s
  }
  .snowflake:nth-of-type(2){
    left:20%;-webkit-animation-delay:6s,.5s;animation-delay:6s,.5s
  }
  .snowflake:nth-of-type(3){
    left:30%;-webkit-animation-delay:4s,2s;animation-delay:4s,2s
  }
  .snowflake:nth-of-type(4){
    left:40%;-webkit-animation-delay:2s,2s;animation-delay:2s,2s
  }
  .snowflake:nth-of-type(5){
    left:50%;-webkit-animation-delay:8s,3s;animation-delay:8s,3s
  }
  .snowflake:nth-of-type(6){
    left:60%;-webkit-animation-delay:6s,2s;animation-delay:6s,2s
  }
  .snowflake:nth-of-type(7){
    left:70%;-webkit-animation-delay:2.5s,1s;animation-delay:2.5s,1s
  }
  .snowflake:nth-of-type(8){
    left:80%;-webkit-animation-delay:1s,0s;animation-delay:1s,0s
  }
  .snowflake:nth-of-type(9){
    left:90%;-webkit-animation-delay:3s,1.5s;animation-delay:3s,1.5s
  }
  .snowflake:nth-of-type(10){
    left:25%;-webkit-animation-delay:2s,0s;animation-delay:2s,0s
  }
  .snowflake:nth-of-type(11){
    left:65%;-webkit-animation-delay:4s,2.5s;animation-delay:4s,2.5s
  }
</style>

<a href="https://zalo.me/g/zjiluh670" id="linkzalo" target="_blank" rel="noopener noreferrer"><div id="fcta-zalo-tracking" class="fcta-zalo-mess">
<span id="fcta-zalo-tracking">Chat hỗ trợ</span></div><div class="fcta-zalo-vi-tri-nut"><div id="fcta-zalo-tracking" class="fcta-zalo-nen-nut"><div id="fcta-zalo-tracking" class="fcta-zalo-ben-trong-nut"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 460.1 436.6"><path fill="currentColor" class="st0" d="M82.6 380.9c-1.8-.8-3.1-1.7-1-3.5 1.3-1 2.7-1.9 4.1-2.8 13.1-8.5 25.4-17.8 33.5-31.5 6.8-11.4 5.7-18.1-2.8-26.5C69 269.2 48.2 212.5 58.6 145.5 64.5 107.7 81.8 75 107 46.6c15.2-17.2 33.3-31.1 53.1-42.7 1.2-.7 2.9-.9 3.1-2.7-.4-1-1.1-.7-1.7-.7-33.7 0-67.4-.7-101 .2C28.3 1.7.5 26.6.6 62.3c.2 104.3 0 208.6 0 313 0 32.4 24.7 59.5 57 60.7 27.3 1.1 54.6.2 82 .1 2 .1 4 .2 6 .2H290c36 0 72 .2 108 0 33.4 0 60.5-27 60.5-60.3v-.6-58.5c0-1.4.5-2.9-.4-4.4-1.8.1-2.5 1.6-3.5 2.6-19.4 19.5-42.3 35.2-67.4 46.3-61.5 27.1-124.1 29-187.6 7.2-5.5-2-11.5-2.2-17.2-.8-8.4 2.1-16.7 4.6-25 7.1-24.4 7.6-49.3 11-74.8 6zm72.5-168.5c1.7-2.2 2.6-3.5 3.6-4.8 13.1-16.6 26.2-33.2 39.3-49.9 3.8-4.8 7.6-9.7 10-15.5 2.8-6.6-.2-12.8-7-15.2-3-.9-6.2-1.3-9.4-1.1-17.8-.1-35.7-.1-53.5 0-2.5 0-5 .3-7.4.9-5.6 1.4-9 7.1-7.6 12.8 1 3.8 4 6.8 7.8 7.7 2.4.6 4.9.9 7.4.8 10.8.1 21.7 0 32.5.1 1.2 0 2.7-.8 3.6 1-.9 1.2-1.8 2.4-2.7 3.5-15.5 19.6-30.9 39.3-46.4 58.9-3.8 4.9-5.8 10.3-3 16.3s8.5 7.1 14.3 7.5c4.6.3 9.3.1 14 .1 16.2 0 32.3.1 48.5-.1 8.6-.1 13.2-5.3 12.3-13.3-.7-6.3-5-9.6-13-9.7-14.1-.1-28.2 0-43.3 0zm116-52.6c-12.5-10.9-26.3-11.6-39.8-3.6-16.4 9.6-22.4 25.3-20.4 43.5 1.9 17 9.3 30.9 27.1 36.6 11.1 3.6 21.4 2.3 30.5-5.1 2.4-1.9 3.1-1.5 4.8.6 3.3 4.2 9 5.8 14 3.9 5-1.5 8.3-6.1 8.3-11.3.1-20 .2-40 0-60-.1-8-7.6-13.1-15.4-11.5-4.3.9-6.7 3.8-9.1 6.9zm69.3 37.1c-.4 25 20.3 43.9 46.3 41.3 23.9-2.4 39.4-20.3 38.6-45.6-.8-25-19.4-42.1-44.9-41.3-23.9.7-40.8 19.9-40 45.6zm-8.8-19.9c0-15.7.1-31.3 0-47 0-8-5.1-13-12.7-12.9-7.4.1-12.3 5.1-12.4 12.8-.1 4.7 0 9.3 0 14v79.5c0 6.2 3.8 11.6 8.8 12.9 6.9 1.9 14-2.2 15.8-9.1.3-1.2.5-2.4.4-3.7.2-15.5.1-31 .1-46.5z"></path></svg></div><div id="fcta-zalo-tracking" class="fcta-zalo-text">Chat ngay</div></div></div></a>
<style>
@keyframes    zoom{0%{transform:scale(.5);opacity:0}50%{opacity:1}to{opacity:0;transform:scale(1)}}@keyframes    lucidgenzalo{0% to{transform:rotate(-25deg)}50%{transform:rotate(25deg)}}.jscroll-to-top{bottom:100px}.fcta-zalo-ben-trong-nut svg path{fill:#fff}.fcta-zalo-vi-tri-nut{position:fixed;bottom:24px;right:20px;z-index:999}.fcta-zalo-nen-nut,div.fcta-zalo-mess{box-shadow:0 1px 6px rgba(0,0,0,.06),0 2px 32px rgba(0,0,0,.16)}.fcta-zalo-nen-nut{width:50px;height:50px;text-align:center;color:#fff;background:#4FB8FF;border-radius:50%;position:relative}.fcta-zalo-nen-nut::after,.fcta-zalo-nen-nut::before{content:"";position:absolute;border:1px solid #4FB8FF;background:#4FB8FF;z-index:-1;left:-20px;right:-20px;top:-20px;bottom:-20px;border-radius:50%;animation:zoom 1.9s linear infinite}.fcta-zalo-nen-nut::after{animation-delay:.4s}.fcta-zalo-ben-trong-nut,.fcta-zalo-ben-trong-nut i{transition:all 1s}.fcta-zalo-ben-trong-nut{position:absolute;text-align:center;width:60%;height:60%;left:10px;bottom:25px;line-height:70px;font-size:25px;opacity:1}.fcta-zalo-ben-trong-nut i{animation:lucidgenzalo 1s linear infinite}.fcta-zalo-nen-nut:hover .fcta-zalo-ben-trong-nut,.fcta-zalo-text{opacity:0}.fcta-zalo-nen-nut:hover i{transform:scale(.5);transition:all .5s ease-in}.fcta-zalo-text a{text-decoration:none;color:#fff}.fcta-zalo-text{position:absolute;top:6px;text-transform:uppercase;font-size:12px;font-weight:700;transform:scaleX(-1);transition:all .5s;line-height:1.5}.fcta-zalo-nen-nut:hover .fcta-zalo-text{transform:scaleX(1);opacity:1}div.fcta-zalo-mess{position:fixed;bottom:29px;right:58px;z-index:99;background:#fff;padding:7px 25px 7px 15px;color:#4FB8FF;border-radius:50px 0 0 50px;font-weight:700;font-size:15px}.fcta-zalo-mess span{color:#4FB8FF!important}
span#fcta-zalo-tracking{font-family:Roboto;line-height:1.5}.fcta-zalo-text{font-family:Roboto}
</style>
<script>
if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) )
{document.getElementById("linkzalo").href="https://zalo.me/g/zjiluh670";}
</script><?php /**PATH /www/wwwroot/aoyi.store/public/theme/v2board/dashboard.blade.php ENDPATH**/ ?>