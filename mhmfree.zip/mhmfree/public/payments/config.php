<?php
const CONFIG = [
                    'DOMAINV2B' => "aoyi.store", //domain của website
                    'TOKEN' => "e51b543567042cc5be58e6acb5d16c28",//lấy từ api.zenpn.com
                    'KEYWORD' => "dhaoyi", //chữ thường không in hoa( nội dung chuyển khoản)
                    'URL' =>[
                        'CALLBACK'=> "https://aoyi.store/payments/hook.php"
                        ],
                    'TELEGRAM' =>[
                        'USER_ID'=> "", // truy cập https://t.me/getmyid_bot để lấy
                        'TOKEN_BOT'=> "6389264192:AAFoyELnYy_op1FWd0MNr0aM2REFJGrfgA4" // Nếu dùng bot mặc định vui lòng chat với https://t.me/botzenpn_bot để nhận thông báo
                        ],
                    'DATABASE' =>[
                        'HOST'=> "localhost", 
                        'USERNAME'=> "aoyi.io.vn",
                        'PASSWORD'=> "aoyi.io.vn",
                        'DBNAME'=> "aoyi.io.vn"
                        ],
                    'GATE' =>[
                        'VIETTELPAY'=> [
                            'ACCOUNT_NUMBER' => "9704229203196383882", // số tài khoản
                            'ACCOUNT_NAME' => "TRAN BUI NHUT HY", // chủ tài khoản
                            'BANKID' => "970422"
                        ],
                        'ACB'=> [
                            'ACCOUNT_NUMBER' => "", // số tài khoản
                            'ACCOUNT_NAME' => "DAU DUC DUY", // chủ tài khoản
                            'BANKID' => "970416"
                        ],
                    ]
                ];